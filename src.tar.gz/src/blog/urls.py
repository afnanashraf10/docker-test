from django.urls import path

from . import views

# urlpatterns = patterns(
#     'talk.views',
#     # url('', 'home'),

#     # api
#     url(r'^api/v1/posts/$', 'post_collection'),
#     url(r'^api/v1/posts/(?P<pk>[0-9]+)$', 'post_element')
# )
urlpatterns = [
    path('list/', views.post_collection, name='post'),
    path('<int:pk>/', views.post_element, name='post_element'),
    path('create/', views.post_collection, name='create_post'),
]