from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Post
from .serializers import PostSerializer
from django.http import JsonResponse
from rest_framework import status


@api_view(['GET', 'POST'])
def post_collection(request):
    if request.method == 'GET':
        posts = Post.objects.all()
        data = [{'id': x.id, 'title': x.title,'duration': x.duration} for x in posts]
        return JsonResponse({'response': 'success', 'data': data})
    elif request.method == 'POST':
        data = {'title': request.data.get('title'),
                'content': request.data.get('content'),
                'duration': request.data.get('duration'),
                'description': request.data.get('description')}
        serializer = PostSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    return JsonResponse({'response': 'failed', 'message': 'method not allowed'})

                                                                                                                                
def post_element(request, pk):
    if request.method == 'GET':
        try:
            post = Post.objects.get(pk=pk)
        except Post.DoesNotExist:
            return JsonResponse({'status_code': 404, 'response': 'failed',
                                 'message': 'No dataavailable!'})
        data = {'title': post.title, 'content': post.content, 'description': post.description,
                'duration': post.duration, 'created_at': post.created_at}
        return JsonResponse({'response': 'success', 'data': data})
    return JsonResponse({'response': 'failed', 'message': 'Method not allowed'})

