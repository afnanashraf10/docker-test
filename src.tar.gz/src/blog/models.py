from django.db import models


# Create your models here.

class Post(models.Model):
    title = models.TextField()
    content = models.TextField()
    duration = models.CharField(max_length=20)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now=True)

